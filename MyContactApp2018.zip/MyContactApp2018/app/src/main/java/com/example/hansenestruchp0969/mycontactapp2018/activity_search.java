package com.example.hansenestruchp0969.mycontactapp2018;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class activity_search extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
}
